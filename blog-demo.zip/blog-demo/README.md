# Blog Management System

This project is a simple blog management system using Node.js, Express, MongoDB, and EJS for server-side rendering.

## Features

- Create, read, update, and delete blogs
- Manage categories for blogs
- Upload and display featured images for blogs
- Server-side rendering with EJS

## Installation

1. Clone the repository:
    ```
    git clone <repository-url>
    ```

2. Install dependencies:
    ```
    cd blog-demo
    npm install
    ```

3. Create a `.env` file in the root directory and add your MongoDB URI:
    ```
    MONGO_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/blogDB?retryWrites=true&w=majority
    ```

4. Start the server:
    ```
    npm start
    ```

5. Open your browser and go to `http://localhost:3000`.

## File Structure

